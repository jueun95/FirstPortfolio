package com.holictype.board.controller;

import java.net.URLEncoder;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.holictype.board.domain.BoardDto;
import com.holictype.board.domain.PageHandler;
import com.holictype.board.domain.SearchCondition;
import com.holictype.board.service.BoardService;

@Controller
@RequestMapping("/review")
public class BoardController {

	@Autowired
	BoardService boardService;
	
	@PostMapping("/modify")
	public String modify(BoardDto boardDto, HttpSession session, Model m, RedirectAttributes rattr) {
		
		String writer = (String) session.getAttribute("id");
		
		boardDto.setWriter(writer);
		
		
		try {
			
			int modifyCnt = boardService.modify(boardDto);
			
			if ( modifyCnt !=1 )
				throw new Exception("modify failed");
			
			rattr.addFlashAttribute("msg", "MOD_OK");
			
			return "redirect:/review/list";
			
		} catch(Exception e) {
			e.printStackTrace();
			
			m.addAttribute("mode", "new");
			m.addAttribute("boardDto", boardDto);
			m.addAttribute("msg", "MOD_ERROR");
			
			return "post";			
		}
	}
	
	@PostMapping("/write")
	public String write(BoardDto boardDto, HttpSession session, Model m, RedirectAttributes rattr) {
		
		String writer = (String) session.getAttribute("id");
		
		boardDto.setWriter(writer);
		
		try {
			if(boardService.write(boardDto) != 1)
				throw new Exception("Write failed");
			
			rattr.addFlashAttribute("msg","WRT_OK");
			
			return "redirect:/review/list";
		} catch(Exception e) {
			e.printStackTrace();
			
			m.addAttribute("mode", "new");
			m.addAttribute("boardDto", boardDto);
			m.addAttribute("msg", "WRT_ERROR");
			
			return "post";
					
		}			
	}
	
	@GetMapping("/post")
	public String write(Model m) {
		
		m.addAttribute("mode", "new");
		return "post";
	}
	
	@PostMapping("/remove")
	public String remove(Integer bno, Integer page, RedirectAttributes rattr, Integer pageSize, Model m, HttpSession session) {
		
		String writer = (String)session.getAttribute("id");
		System.out.println(writer);
		try {
			
			m.addAttribute("page", page);
			m.addAttribute("pageSize", pageSize);
			
			int rowCnt = boardService.remove(bno, writer);
			System.out.println(rowCnt);
			if(rowCnt != 1)
				throw new Exception("board remove error");
			
			rattr.addFlashAttribute("msg", "DEL_OK");			
		} catch (Exception e) {
			e.printStackTrace();
			
			rattr.addFlashAttribute("msg", "DEL_ERROR");
		}
		return "redirect:/review/list";
	}
	
	@GetMapping("/read")
	public String read(Integer page, Integer pageSize, Integer bno, Model m) {
		
		try {
			BoardDto boardDto = boardService.read(bno);
			
			m.addAttribute("boardDto",boardDto);
			m.addAttribute("page",page);
			m.addAttribute("pageSize", pageSize);
			m.addAttribute("bno", bno);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "post";	
	}
	
	@GetMapping("/list")
	public String list(SearchCondition sc, Model m, HttpServletRequest request) {
	
		if(!loginCheck(request)) {
			return "redirect:/login/login?toURL=" + request.getRequestURL();
		}
						
		try {
			int totalCnt = boardService.getCount();
			
			PageHandler pageHandler = new PageHandler(totalCnt, sc);
			
			List<BoardDto> list = boardService.getSelectSearchPage(sc);
			
			m.addAttribute("list", list);
			m.addAttribute("ph", pageHandler);			

		} catch (Exception e) {
			e.printStackTrace();
			
			m.addAttribute("msg","LIST_ERR");			
		}
		
		return "reviewList";
	}
	
	private boolean loginCheck(HttpServletRequest request) {
		HttpSession session = request.getSession();		

		return session.getAttribute("id") != null; 
	}
}
