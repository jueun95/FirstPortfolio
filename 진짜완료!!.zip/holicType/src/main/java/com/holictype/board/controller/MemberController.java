package com.holictype.board.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.holictype.board.domain.User;
import com.holictype.board.service.UserService;

@Controller
public class MemberController {
	
	@Autowired
	UserService service;
	
	@GetMapping("/add")
	public String register(User user) throws Exception {		

		return "registerForm";
	}
	
	@PostMapping("/add")
	public String register1(User user) throws Exception{
		System.out.println("user ="+user);
		service.register(user);
		
		return "index";
	}
	
}
