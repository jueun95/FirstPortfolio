package com.holictype.board.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller("/personal")
public class PersonalController {

		@GetMapping("/personal")
		public String personal() {
			
			return "/personal";
		}
}
