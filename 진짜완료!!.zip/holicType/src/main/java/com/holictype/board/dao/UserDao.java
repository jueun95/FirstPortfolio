package com.holictype.board.dao;

import com.holictype.board.domain.User;

public interface UserDao {
	
	public int register(User user) throws Exception;
	
	public User login(User user) throws Exception;

}
