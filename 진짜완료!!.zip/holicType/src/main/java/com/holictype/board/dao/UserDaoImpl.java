package com.holictype.board.dao;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.holictype.board.domain.User;

@Repository
public class UserDaoImpl implements UserDao{
	
	@Autowired
	SqlSession session;	
	
	String namespace = "com.holictype.mapper.memberMapper.";
	
	@Override
	public int register(User user) throws Exception {
		System.out.println("userDaoimpl ="+user);
		return session.insert(namespace+"register",user);
	}	
	
	@Override
	public User login(User user) throws Exception {
		return session.selectOne(namespace+"login"+ user);
	}
}
