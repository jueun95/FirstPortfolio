package com.holictype.board.domain;

import java.util.Date;
import java.util.Objects;

public class BoardDto {	
	private Integer bno;
	private String title;
	private String sname;
	private String content;
	private String writer;
	private Date regDate;
	
	public BoardDto() {}	

	public BoardDto(Integer bno, String title, String sname, String content, String writer, Date regDate) {
		this.bno = bno;
		this.title = title;
		this.sname = sname;
		this.content = content;
		this.writer = writer;
		this.regDate = regDate;
	}

	public Integer getBno() {
		return bno;
	}

	public void setBno(Integer bno) {
		this.bno = bno;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Date getregDate() {
		return regDate;
	}

	public void setregDate(Date regDate) {
		this.regDate = regDate;
	}	
	
	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getWriter() {
		return writer;
	}

	@Override
	public int hashCode() {
		return Objects.hash(bno, content, sname, title, writer);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BoardDto other = (BoardDto) obj;
		return Objects.equals(bno, other.bno) && Objects.equals(content, other.content)
				&& Objects.equals(sname, other.sname) && Objects.equals(title, other.title)
				&& Objects.equals(writer, other.writer);
	}

	@Override
	public String toString() {
		return "BoardDto [bno=" + bno + ", title=" + title + ", sname=" + sname + ", content=" + content + ", writer="
				+ writer + ", regDate=" + regDate + "]";
	}
	
	
	
}
