package com.holictype.board.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.holictype.board.dao.BoardDao;
import com.holictype.board.domain.BoardDto;
import com.holictype.board.domain.SearchCondition;

@Service
public class BoardServiceImpl implements BoardService{

	@Autowired
	BoardDao boardDao;
	
	@Override
	public int getCount() throws Exception {
		return boardDao.count();
	}
	
	@Override
	public int remove(Integer bno, String writer) throws Exception {
		System.out.println("Service delete = "+boardDao.delete(bno, writer));
		return boardDao.delete(bno, writer);
	}
	
	@Override
	public int write(BoardDto boardDto) throws Exception{
		return boardDao.insert(boardDto);
	}
	
	@Override
	public List<BoardDto> getList() throws Exception{
		return boardDao.selectAll();
	}
	
	@Override
	public BoardDto read(Integer bno) throws Exception {
	      BoardDto boardDto = boardDao.select(bno);
	      return boardDto;
	}
	
	@Override
	public List<BoardDto> getPage(Map map) throws Exception {
	      return boardDao.selectPage(map);
	  }
	
	@Override
	public int modify(BoardDto boardDto) throws Exception {
	      return boardDao.update(boardDto);
	}

	@Override
	public List<BoardDto> getSelectSearchPage(SearchCondition sc) throws Exception {
	      return boardDao.selectSearchPage(sc);
	  }
	
	@Override
	public int getSearchResultCnt(SearchCondition sc) throws Exception {
	      return boardDao.searchResultCnt(sc);
	  }	
	
}
