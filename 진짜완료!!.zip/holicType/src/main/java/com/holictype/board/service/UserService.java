package com.holictype.board.service;

import com.holictype.board.domain.User;

public interface UserService {

	public void register(User user) throws Exception;
	
	public User login(User user) throws Exception;
}