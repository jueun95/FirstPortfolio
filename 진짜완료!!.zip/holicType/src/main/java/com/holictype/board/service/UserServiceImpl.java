package com.holictype.board.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.holictype.board.dao.UserDao;
import com.holictype.board.domain.User;

@Service
public class UserServiceImpl implements UserService {
	
	@Autowired
	private UserDao dao;
	
	@Override
	public void register(User user) throws Exception{
		System.out.println("userService ="+user);
		dao.register(user);
	}	
	
	@Override
	public User login(User user) throws Exception{
		return dao.login(user);
	}
}
